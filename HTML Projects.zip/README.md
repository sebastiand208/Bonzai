# Bonzai

A website to help students cope with stress. Programmed in HTML, CSS, and Javascript.
